import java.util.Scanner;

// Class utama untuk menjalankan program
public class Main {
    public static void main(String[] args) {

        // Menyimpan 5 objek mahasiswa ke dalam array
        Mahasiswa[] daftar = new Mahasiswa[5];

        // Mengisi data mahasiswa
        daftar[0] = new Mahasiswa("Dimas Ramadhan", "2546048", "Manajemen", 2.79);
        daftar[1] = new Mahasiswa("Dino Sadewa", "2521395", "Teknik Sipil", 2.52);
        daftar[2] = new Mahasiswa("Nabila Permata", "2540495", "Teknik Informatika", 3.31);
        daftar[3] = new Mahasiswa("Galih Nugroho", "2538893", "Desain Grafis", 3.35);
        daftar[4] = new Mahasiswa("Alya Wijaya", "2565392", "Ilmu Komunikasi", 2.88);

        // Membuat Scanner untuk menerima input pengguna
        Scanner input = new Scanner(System.in);

        // Meminta input NIM mahasiswa yang ingin diupdate
        System.out.print("Masukkan NIM mahasiswa yang ingin diupdate: ");
        String nimCari = input.nextLine();

        // Penanda apakah mahasiswa ditemukan
        boolean ditemukan = false;

        // Mencari mahasiswa berdasarkan NIM
        for (Mahasiswa mhs : daftar) {
            if (mhs.getNim().equals(nimCari)) {
                ditemukan = true;

                // Meminta input IPK baru
                System.out.print("Masukkan IPK baru (0 - 4): ");
                String ipkInput = input.nextLine().replace(',', '.');

                try {
                    double ipkBaru = Double.parseDouble(ipkInput);

                    // Validasi IPK baru
                    if (ipkBaru >= 0 && ipkBaru <= 4) {
                        mhs.updateIpk(ipkBaru);

                        System.out.println("\nData berhasil diperbarui!\n");
                        System.out.println("=== Data Mahasiswa ===");
                        mhs.tampilkanInfo();
                    } else {
                        System.out.println("\nIPK tidak valid. Masukkan nilai antara 0 sampai 4.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("\nInput IPK tidak valid. Masukkan angka, misalnya 3.5 atau 3,5.");
                }

                break;
            }
        }

        // Jika NIM tidak ditemukan
        if (!ditemukan) {
            System.out.println("Mahasiswa dengan NIM tersebut tidak ditemukan.");
        }

        input.close();
    }
}