// Class utama untuk menjalankan program
public class Main {
    public static void main(String[] args) {

        // Menyimpan 5 objek mahasiswa ke dalam array
        Mahasiswa[] daftar = new Mahasiswa[5];

        // Mengisi data mahasiswa dengan data acak
        daftar[0] = new Mahasiswa("Dimas Ramadhan", "2546048", "Manajemen", 2.79);
        daftar[1] = new Mahasiswa("Dino Sadewa", "2521395", "Teknik Sipil", 2.52);
        daftar[2] = new Mahasiswa("Nabila Permata", "2540495", "Teknik Informatika", 3.31);
        daftar[3] = new Mahasiswa("Galih Nugroho", "2538893", "Desain Grafis", 3.35);
        daftar[4] = new Mahasiswa("Alya Wijaya", "2565392", "Ilmu Komunikasi", 2.88);

        // Menampilkan seluruh data mahasiswa menggunakan loop
        System.out.println("=== Data Mahasiswa ===");
        for (Mahasiswa mhs : daftar) {
            mhs.tampilkanInfo();
        }
    }
}